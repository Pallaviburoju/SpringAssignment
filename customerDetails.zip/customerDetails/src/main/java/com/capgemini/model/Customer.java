package com.capgemini.model;

public class Customer {
	
	private String customerId;
	private String customerName;
	private String customerContact;
	private String customerAddress;
	
	private Address address;

	
	public Customer() {
		super();
	}

	
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", customerContact="
				+ customerContact + ", customerAddress=" + customerAddress + ", address=" + address + "]";
	}


	public Customer(String customerId, String customerName, String customerContact, String customerAddress,
			Address address) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.customerContact = customerContact;
		this.customerAddress = customerAddress;
		this.address = address;
	}

	public String getCustomerId() {
		return customerId;
	}

	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerContact() {
		return customerContact;
	}

	public void setCustomerContact(String customerContact) {
		this.customerContact = customerContact;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	
//	public void details() {
//		//System.out.println("Details of address are "+ this.address);
//		//System.out.println(" Customer details is "+ this.customerId +" Customer contact "+ this.customerContact);
//		
//	}
	
}
