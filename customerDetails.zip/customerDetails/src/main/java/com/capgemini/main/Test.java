package com.capgemini.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.model.Customer;

public class Test {
	
	public static void main(String[] args) {
		 
        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
        Customer customer = (Customer) context.getBean("Customer");
//	    customer.details(); 
        System.out.println(customer);
	
 // Can write in the following way also      
        
//		 Resource resource=new ClassPathResource("beans.xml");  
//		    
//			@SuppressWarnings("deprecation")
//			BeanFactory factory=new XmlBeanFactory(resource);  
//		      
//		    Customer customer=(Customer)factory.getBean("Customer");  
//		    customer.details(); 
 //       System.out.println(customer);
    }
}
