package customerDetails;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capgemini.model.Address;
import com.capgemini.model.Customer;

public class CustomerTest {

	//public Customer customer = new Customer();
	public Customer customer= new Customer("2", "Pal", "8934697836", "Hyd", new Address("Sai nagar colony", "Hyderabad", "Telangana", "509103", "India"));
	
	@Test
	public void customerIdTest() {
		customer.setCustomerId("2");
		assertEquals("Hyd",customer.getCustomerAddress());
	}
}
