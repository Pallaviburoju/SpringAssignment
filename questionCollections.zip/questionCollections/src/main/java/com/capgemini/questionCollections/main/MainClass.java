package com.capgemini.questionCollections.main;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.questionCollections.model.Question;


public class MainClass {
	public static void main(String args[]) {
		
	        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
	        Question question = (Question) context.getBean("Question");
	       
	        System.out.println(question.getQuestionId()+" " + question.getQuestion()+" "+ question.getAnswers1()+" "+question.getAnswers2()+" "+question.getAnswers3());

	        
	}
}
