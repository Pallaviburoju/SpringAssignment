package questionCollections;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.junit.Test;

import com.capgemini.questionCollections.model.Question;

public class QuestionTest {
	
	List<String> list1 = new ArrayList<String>();
	Set<String> set1 = new HashSet<String>();
	Map<Integer, String> map1 = new HashMap<Integer,String>();

	@Test
	public void questionTest() {
		list1.add("Eating");
		set1.add("Sleeping");
		map1.put(10, "Watching movies");
		Question question = new Question(1, "what are the languages you know", list1, set1, map1);
		assertEquals(list1, question.getAnswers1());
	}
}
